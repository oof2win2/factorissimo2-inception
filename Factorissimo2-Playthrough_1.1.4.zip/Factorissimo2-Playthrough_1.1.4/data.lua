require("prototypes.inputcombinator")
require("prototypes.styles")

require("prototypes.technology.water")
require("prototypes.technology.belts") -- input research