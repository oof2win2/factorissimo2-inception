local s = data.raw["gui-style"]["default"]

s["f2pl_horizontal_centerflow"] = {
    type = "horizontal_flow_style",
    horizontal_align = "center"
}