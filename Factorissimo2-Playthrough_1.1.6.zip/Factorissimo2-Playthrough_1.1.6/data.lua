require("prototypes.inputcombinator")
require("prototypes.styles")

require("prototypes.technology.water")
require("prototypes.technology.belts") -- input research

require("prototypes.map-gen-preset") -- map generation preset